# Printing command-line arguments

from sys import argv

for s in argv:
    print(s)
