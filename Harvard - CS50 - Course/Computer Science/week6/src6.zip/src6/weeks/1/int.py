# get_int and print

from cs50 import get_int

i = get_int("Integer: ")
print("hello,", i)
