# get_string and print

from cs50 import get_string

s = get_string("Name: ")
print("hello,", s)
