# get_int and print

from cs50 import get_int

f = get_float("Float: ")
print("hello,", f)
