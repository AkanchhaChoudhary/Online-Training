// get_float and printf with %f

#include <cs50.h>
#include <stdio.h>

int main(void)
{
    float f = get_float("Float: ");
    printf("hello, %f\n", f);
}
