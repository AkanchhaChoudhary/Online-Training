name = "Alice"
coordinates = (10.0, 20.0)
names = ["Alice", "Bob", "Charlie"]
