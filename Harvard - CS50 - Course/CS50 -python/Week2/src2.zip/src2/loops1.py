names = ["Alice", "Bob", "Charlie"]
for name in names:
    print(name)
