DELETE FROM countries WHERE destination = 'Tokyo';
